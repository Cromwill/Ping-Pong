﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PongV2
{
    public class Side : MonoBehaviour
    {
        private List<IPlayer> Players = new List<IPlayer>();
        private Score Score;
        public GameObject PlayerPrototype;
        private Transform _selfTransform;

        private void Start()
        {
            _selfTransform = GetComponent<Transform>();
            PlayerFactory factory = new PlayerFactory(this, PlayerPrototype);
            factory.CreateSimple();
            factory.CreateSimple();
        }

        public void AddPlayer(IPlayer player)
        {
            Players.Add(player);
            
            for(int i = 0; i < Players.Count; i++)
            {
                player.UpdateClampArea(new Rect(_selfTransform.position.x, _selfTransform.position.y - (i * 1), 0, 4));
            }
        }
    }

    public class Score
    {
        private float _value;
        public float Value
        {
            get
            {
                return _value;
            }
            set
            {
                _value = value;
                if(OnScoreChange != null)
                {
                    OnScoreChange(this, _value);
                }
            }
        }
        public event System.Action<Score, float> OnScoreChange, OnScoreAdd, OnScoreReduce;

        public void AddScore(float value)
        {
            Value += value;
            if(OnScoreAdd != null)
            {
                OnScoreAdd(this, Value);
            }
        }

        public void ReduceScore(float value)
        {
            if(Value < value)
            {
                throw new System.InvalidOperationException("value less current score value");
            }
            Value -= value;
            if(OnScoreReduce != null)
            {
                OnScoreReduce(this, value);
            }
        }

    }

    public interface IPlayer
    {
        IAvatar GetAvatar();
        void SetAvatar(IAvatar avatar);
        void UpdateClampArea(Rect clampArea);
    }

    public interface IAvatar
    {
        Transform GetTransform();
        void MoveUp(Rect clampArea);
        void MoveDown(Rect clampArea);
    }
}