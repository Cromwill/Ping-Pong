﻿using UnityEngine;

namespace PongV2
{
    public class KeyboardPlayer : MonoBehaviour, IPlayer
    {
        private IAvatar _avatar;
        private Rect ClampArea;

        public IAvatar GetAvatar()
        {
            return _avatar;
        }

        public void SetAvatar(IAvatar avatar)
        {
            _avatar = avatar;
        }

        public void UpdateClampArea(Rect clampArea)
        {
            ClampArea = clampArea;
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.W))
            {
                _avatar.MoveUp(ClampArea);
            }
            if (Input.GetKeyDown(KeyCode.S))
            {
                _avatar.MoveDown(ClampArea);
            }
        }
    }
}