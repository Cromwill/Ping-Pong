﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace PongV2
{
    class PlayerFactory
    {
        private Side _side;
        private GameObject _prototype;

        public PlayerFactory(Side side, GameObject prototype)
        {
            _side = side;
            _prototype = prototype;
        }

        public void CreateSimple()
        {
            GameObject playerObject = GameObject.Instantiate(_prototype, _side.transform);
            playerObject.transform.position = _side.transform.position;
            IPlayer player =  playerObject.GetComponent<IPlayer>();
            IAvatar avatar = playerObject.GetComponent<IAvatar>();
            player.SetAvatar(avatar);
            _side.AddPlayer(player);
        }
    }
}
