﻿using UnityEngine;

namespace PongV2
{
    public class SimpleAvatar : MonoBehaviour, IAvatar
    {
        private Transform _selfTransform;

        private void Start()
        {
            _selfTransform = GetComponent<Transform>();            
        }

        public Transform GetTransform()
        {
            return _selfTransform;
        }

        public void MoveDown(Rect clampArea)
        {
            ClampedTranslate(Vector3.down, clampArea);
        }
        public void MoveUp(Rect clampArea)
        {
            ClampedTranslate(Vector3.up, clampArea);
        }

        public void ClampedTranslate(Vector3 direction, Rect clampArea)
        {
            _selfTransform.Translate(direction);
            Vector3 position = _selfTransform.position;
            position = new Vector3(Mathf.Clamp(position.x, clampArea.xMin, clampArea.xMax),
                                    Mathf.Clamp(position.y, clampArea.yMin, clampArea.yMax), 0);
            _selfTransform.position = position;
        }
    }
}