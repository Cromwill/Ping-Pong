﻿using UnityEngine;
using UnityEditor;
using PongV2;

[CustomEditor(typeof(KeyboardPlayer))]
public class PlayerInspector : Editor
{
    public override void OnInspectorGUI()
    {
        KeyboardPlayer player = (KeyboardPlayer)target;
        base.OnInspectorGUI();
    }
}